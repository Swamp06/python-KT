from database import engine, Session, Base
from models import  Student, Subject, AcademicRecord

Base.metadata.create_all(engine)
session = Session()

student1 = Student(
    first_name = "Осман", 
    last_name = "Янарсанов",
    age = 18,
    group_name = "3P1",
    email = "yanarsanov@gmail.com"
)

student2 = Student(
    first_name = "Илез", 
    last_name = "Гадаборшев",
    age = 19,
    group_name = "3P1",
    email = "gadaborshev@gmail.com"
)

student3 = Student(
    first_name = "Ибрагим", 
    last_name = "Оздоев",
    age = 20,
    group_name = "3P1",
    email = "ozdoev@gmail.com"
)

subject1 = Subject(
    name = "Python",
    teacher = "Ислам"
)

subject2 = Subject(
    name = "React",
    teacher = "Адам"
)

subject3 = Subject(
    name = "HTML",
    teacher = "Узбек"
)

session.add_all([
    student1, student2, student3, subject1, subject2, subject3
])
session.commit()

record1 = AcademicRecord(
    student_id = student1.id,
    subject_id = subject1.id,
    grade = 6,
    attendance = "present"
)

record2 = AcademicRecord(
    student_id = student2.id,
    subject_id = subject2.id,
    grade = 10,
    attendance = "present"
)

record3 = AcademicRecord(
    student_id = student3.id,
    subject_id = subject3.id,
    grade = 2,
    attendance = "excused"
)

session.add_all([record1, record2, record3])
session.commit()

print('База данных создана!')