from sqlalchemy import Column, Integer, String, ForeignKey, Float
from sqlalchemy.orm import relationship
from database import Base

class Student(Base):
    __tablename__ = "students"

    id = Column(Integer, primary_key=True)
    first_name = Column(String, nullable=False)
    last_name = Column(String, nullable=False)
    age = Column(Integer)
    group_name = Column(String, nullable=False)
    email = Column(String, unique=True, nullable=False)

    records = relationship("AcademicRecord", back_populates="student")


class Subject(Base):
    __tablename__ = "subjects"

    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    teacher = Column(String, nullable=False)

    records = relationship("AcademicRecord", back_populates="subject")


class AcademicRecord(Base):
    __tablename__ = "academic_records"

    id = Column(Integer, primary_key=True)
    student_id = Column(Integer, ForeignKey("students.id"))
    subject_id = Column(Integer, ForeignKey("subjects.id"))
    grade = Column(Float)
    attendance = Column(String, nullable=False)

    student = relationship("Student", back_populates="records")
    subject = relationship("Subject", back_populates="records")