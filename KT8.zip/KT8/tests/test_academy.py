from models import Student , Subject , AcademicRecord

def test_add_academic(session):
    student = Student(
        first_name = "Ivan",
        last_name = "Kuzmin",
        age = 15,
        group_name = "3P1",
        email = "ivan@gmail.com"
    )
    subject = Subject(
        name = "Python",
        teacher = "Islam B"
    )

    session.add_all([student , subject])
    session.close()

    record = AcademicRecord(
        student_id = student.id,
        subject_id = subject.id,
        grade = 10,
        attendance = "present"
    )

    session.add(record)
    session.commit()

    saved_record = session.query(AcademicRecord).filter_by(
        student_id = student.id,
        subject_id = subject.id).first() 

    assert saved_record is not None
    assert saved_record.grade == 10
    assert saved_record.attendance == "present"