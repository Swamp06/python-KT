from models import Subject

def test_add_subject(session):
    subject = Subject(
        name = "Python",
        teacher = "Islam B"
    )

    session.add(subject)
    session.commit()

    saved_subject = session.query(Subject).filter_by(name="Python").first()
    assert saved_subject.name == "Python"
    assert saved_subject.teacher == "Islam B"


def test_update_teacher(session):
    subject = Subject(
        name = "React",
        teacher = "Adam"
    )
    session.add(subject)
    session.commit()

    session.query(Subject).filter_by(id=subject.id).update({"teacher": "Ilez G"})
    session.commit()
    
    updated_subject = session.query(Subject).filter_by(id=subject.id).first()
    assert updated_subject.teacher == "Ilez G"