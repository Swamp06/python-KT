import pytest
from models import Student

def test_new_student(session):
    student = Student(
        first_name = "Ivan",
        last_name = "Kuzmin",
        age = 15,
        group_name = "3P1",
        email = "ivan@gmail.com"
    )
    session.add(student)
    session.commit()

    saved_student = session.query(Student).filter_by(
        email="ivan@gmail.com").first()
    
    assert saved_student is not None
    assert saved_student.first_name == "Ivan"

def test_delete_student(session):
    student = Student(
        first_name = "Vlad",
        last_name = "Voronov",
        age = 15,
        group_name = "3P1",
        email = "vlad@gmail.com"
    )
    session.add(student)
    session.commit()

    student_id = student.id
    session.delete(student)
    session.commit()

    deleted_student = session.query(Student).filter_by(id=student_id).first()
    assert deleted_student is None