import pytest
from sqlalchemy import create_engine , event
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from database import Base

@pytest.fixture
def session():
    engine = create_engine("sqlite://" , 
                           connect_args={"check_same_thread": False},
                           poolclass=StaticPool)
    @event.listens_for(engine , "connect")
    def enable_foreign_keys(dbapi_connection , connection_record):
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()

    Base.metadata.create_all(engine)
    TestingSession = sessionmaker(bind=engine)
    db = TestingSession()

    try:
        yield db
    finally:
        db.close()
        Base.metadata.drop_all(engine)
        engine.dispose()